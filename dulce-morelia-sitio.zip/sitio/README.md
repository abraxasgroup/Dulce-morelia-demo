# Dulce Morelia — Web

Web one-page para Dulce Morelia (Quillón, Ñuble). HTML/CSS/JS puro, sin frameworks ni build. Carga instantánea.

## Subir a GitHub Pages
1. Subí TODO el contenido de esta carpeta al repo (index.html + carpeta assets/).
2. Settings → Pages → Source: main / (root) → Save.
3. Listo en https://TU-USUARIO.github.io/NOMBRE-REPO/

IMPORTANTE: subí la carpeta `assets/` completa junto al index.html, o las fotos no cargan.

## Estructura
- index.html              ← la web entera
- assets/optimized/*.jpg  ← las 8 fotos (NO borrar)
